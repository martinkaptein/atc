ATC Read Me File
----------------

We recommend that ATC be installed in a folder called ATC located
at the root of one of your hard drives.  If you have a hard drive 
named c you would install ATC in the folder

	c:\atc

This makes it easier to navigate to the ATC folder when you are ready to play.

Full instructions can be found in the included PDF file

	ATC_Users_Guide.pdf

A summary of commands can be found in the included text file

	ATC_Command_Summary.txt

which may be viewed with the Windows program Notepad.exe or any
other text editor.



Copyright �2009 Will Fastie.  All Rights Reserved.
